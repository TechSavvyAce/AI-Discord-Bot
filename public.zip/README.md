# ChatGPT Backend Services

## Getting Started

1. Run `yarn install`
1. Run `yarn start`. **BE CAREFUL**, `yarn start` does not transpile typescript!
