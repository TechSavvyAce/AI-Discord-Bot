require('dotenv').config();

// External Modules
import API from './apis';
import config from './config';
import ConnectDatabase from './config/database';
import { initSocket } from './socket';
ConnectDatabase(config.mongoURI);
initSocket();